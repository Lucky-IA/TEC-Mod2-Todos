# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['src', 'src.packages', 'tests', 'tests.integration', 'tests.unit']

package_data = \
{'': ['*'],
 'src': ['data/.gitkeep',
         'data/.gitkeep',
         'data/my_list.csv',
         'data/my_list.csv',
         'features/.gitkeep',
         'models/.gitkeep',
         'visualization/.gitkeep'],
 'tests.integration': ['data/*'],
 'tests.unit': ['data/*']}

install_requires = \
['pandas==1.3.5', 'typer>=0.7.0,<0.8.0']

setup_kwargs = {
    'name': 'tec-mod2-todos',
    'version': '0.1.0',
    'description': 'ML Modulo 2',
    'long_description': '# Proyecto Todo List\n\nTEC Monterrey - Machine Learning - Entregable Modulo 2\n\n**Alex Castro Gumiel**\n\n## Project Organization\n\n    ├── LICENSE\n    ├── Makefile           <- Makefile with commands like `make data` or `make train`\n    ├── README.md          <- The top-level README for developers using this project.\n    ├── data\n    │\xa0\xa0 ├── external       <- Data from third party sources.\n    │\xa0\xa0 ├── interim        <- Intermediate data that has been transformed.\n    │\xa0\xa0 ├── processed      <- The final, canonical data sets for modeling.\n    │\xa0\xa0 └── raw            <- The original, immutable data dump.\n    │\n    ├── docs               <- A default Sphinx project; see sphinx-doc.org for details\n    │\n    ├── models             <- Trained and serialized models, model predictions, or model summaries\n    │\n    ├── notebooks          <- Jupyter notebooks. Naming convention is a number (for ordering),\n    │                         the creator\'s initials, and a short `-` delimited description, e.g.\n    │                         `1.0-jqp-initial-data-exploration`.\n    │\n    ├── references         <- Data dictionaries, manuals, and all other explanatory materials.\n    │\n    ├── reports            <- Generated analysis as HTML, PDF, LaTeX, etc.\n    │\xa0\xa0 └── figures        <- Generated graphics and figures to be used in reporting\n    │\n    ├── requirements.txt   <- The requirements file for reproducing the analysis environment, e.g.\n    │                         generated with `pip freeze > requirements.txt`\n    │\n    ├── setup.py           <- makes project pip installable (pip install -e .) so src can be imported\n    ├── src                <- Source code for use in this project.\n    │\xa0\xa0 ├── __init__.py    <- Makes src a Python module\n    │   │\n    │\xa0\xa0 ├── data           <- Scripts to download or generate data\n    │\xa0\xa0 │\xa0\xa0 └── make_dataset.py\n    │   │\n    │\xa0\xa0 ├── features       <- Scripts to turn raw data into features for modeling\n    │\xa0\xa0 │\xa0\xa0 └── build_features.py\n    │   │\n    │\xa0\xa0 ├── models         <- Scripts to train models and then use trained models to make\n    │   │   │                 predictions\n    │\xa0\xa0 │\xa0\xa0 ├── predict_model.py\n    │\xa0\xa0 │\xa0\xa0 └── train_model.py\n    │   │\n    │\xa0\xa0 └── visualization  <- Scripts to create exploratory and results oriented visualizations\n    │\xa0\xa0     └── visualize.py\n    │\n    └── tox.ini            <- tox file with settings for running tox; see tox.readthedocs.io\n\n\n--------\n\n<p><small>Project based on the <a target="_blank" href="https://drivendata.github.io/cookiecutter-data-science/">cookiecutter data science project template</a>. #cookiecutterdatascience</small></p>\n\n\n\n## Project Target \n\n- Organizar el código o los scripts en una estructura de directorio\n- Cree los archivos necesarios de empaquetado\n- Cuide las referencias (imports) intra-paquete\n- Verifique que el código siga el PEP 8\n- Agregue Python annotations a sus funciones\n- Verifique que sus funciones tengan docstrings\n- Agregue pruebas unitarias y de integración que crea convenientes\n- Hacer ejecutable el módulo y probarlo en un venv\n- Cree un repositorio en su cuenta de GitHub y suba el proyecto\n\n## Project Structuring\n\ncookiecutter https://github.com/drivendata/cookiecutter-data-science\n\n- python3 -m venv venv\n- source venv/bin/activate\n- pip install -r requirements.txt\n\n## Package References\n\n   ├── src\n\n   │\xa0\xa0 ├── main_todo.py                 <- Main: Client Methods\n\n   │\xa0\xa0 │\xa0\xa0 ├── packages                 <- Packages Folder\n\n   │   │\xa0\xa0 │\xa0\xa0 ├── class_todo.py        <- Class: Methods Refactored\n\n## PEP 8 Style Guide\n\n- black src/main_todo.py \n- black src/packages/class_todo.py \n\n- flake8 src/main_todo.py\n- flake8 src/packages/class_todo.py \n\n- isort src/main_todo.py \n- isort src/packages/class_todo.py \n\n## Annotations \n\n- src/main_todo.py \n- src/packages/class_todo.py \n- src/tests/unit/test_unit.py \n- src/tests/integration/test_integration.py \n\n## Docstrings\n\n<!-- pip install git+https://github.com/dadadel/pyment.git -->\n- pyment -w src/packages/class_todo.py\n\n- interrogate -vv src/packages/class_todo.py\n\n- pycodestyle --first src/packages/class_todo.py\n- pycodestyle --show-source --show-pep8 src/packages/class_todo.py\n- pycodestyle src/packages/class_todo.py --format=pylint\n\n- pylint src/packages/class_todo.py\n\n## Unit & Integration Tests\n\n- pytest tests/unit/test_unit.py -v\n- pytest tests/integration/test_integration.py -v\n\n## Create Packaging Files\n\n<!-- pipx install poetry -->\n- poetry init\n\n- poetry add pandas==1.3.5\n- poetry add typer\n- poetry add --dev pytest\n- poetry add --dev black\n- poetry add --dev flake8\n- poetry add --dev isort\n- poetry add --dev pyment\n- poetry add --dev interrogate\n- poetry add --dev pycodestyle\n\n- poetry update\n<!-- poetry remove <library-name> -->\n\n- poetry show\n- poetry show --tree\n\n## Execute Packing Modules \n\n- poetry install\n- poetry build\n\n## GitHub Repository\n\nhttps://github.com/Lucky-IA/TEC-Mod2-Todos\n\n- git init\n- git add .\n- git commit -m "first commit"\n\n- git remote add origin https://github.com/Lucky-IA/TEC-Mod2-Todos.git\n- git branch -M main\n- git push -u origin main\n\n- git status\n- git add .\n- git commit -m "update readme"\n- git push\n\n',
    'author': 'Alex Castro Gumiel',
    'author_email': 'None',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0',
}


setup(**setup_kwargs)
